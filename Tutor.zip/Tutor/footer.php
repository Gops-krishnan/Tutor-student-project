  <footer>
    <div class="footer">
      <div class="container">
      

        <div class="col-md-4 col-md-offset-4 pull-right">
          <div class="copyright">
           
            <div class="credits">
            
              <a>Tutor-Finder</a> 
            </div>
			 &copy; Developed By GATEWAY SOFTWARE SOLUTIONS All Rights Reserved.
          </div>
        </div>
      </div>

    </div>
  </footer>





</body>

</html>