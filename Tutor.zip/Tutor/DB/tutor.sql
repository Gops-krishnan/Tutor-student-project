-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 08, 2023 at 04:41 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tutor`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_tutor`
--

CREATE TABLE `add_tutor` (
  `id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `number` varchar(40) NOT NULL,
  `teaching` varchar(40) NOT NULL,
  `address` varchar(40) NOT NULL,
  `subject` varchar(40) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `add_tutor`
--

INSERT INTO `add_tutor` (`id`, `name`, `email`, `number`, `teaching`, `address`, `subject`) VALUES
(10, 'Tejas', 'tejasnitk@gmail.com', '9886750312', '14', 'Bangalore', 'Mathematics'),
(14, 'kirupa', 'gateway.kirupa@gmail.com', '9842242653', '12', 'madurai', 'ComputerScience'),
(12, 'Sabari', 'sabyog@gmail.com', '7397078885', '10', 'cbe', 'Mathematics'),
(13, 'Sabarinathan', 'sabyog@gmail.com', '7397078885', '10', 'cbe', 'Mathematics');

-- --------------------------------------------------------

--
-- Table structure for table `ajax`
--

CREATE TABLE `ajax` (
  `id` int(11) NOT NULL,
  `address` varchar(40) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ajax`
--

INSERT INTO `ajax` (`id`, `address`) VALUES
(14, 'Bangalore'),
(15, 'cbe'),
(16, 'madurai');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `username` varchar(40) NOT NULL,
  `mobile` varchar(40) NOT NULL,
  `password` varchar(500) NOT NULL,
  `institute_name` varchar(40) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `name`, `username`, `mobile`, `password`, `institute_name`) VALUES
(11, 'tejas kumar', 'Tejas11', '9739368139', '$2y$10$fuyaNiOBT8jgD5rpykiTX.zXTEmsn0nyMY7qxXMN1nyYEL/V7J9rO', '14'),
(12, 'wefjcknm ,', 'wjbhcnm ', '9884556666', '$2y$10$vVUcgyezQK5wM76QO6mRweLLLtqhr0sSYofm0lRttj32N1GrxzSPS', '47'),
(13, 'ilakiya', 'skilakiya', '9994993885', '$2y$10$WcHBVaC6eLXEMxgJLfaifOIG728HBDgRw3T20/2rRToBTTLHKS73C', '10'),
(14, 'VENU MATHAV N', 'venumathav', '9632145879', '$2y$10$Gt/PjUhkFIAL.NY0Q0aj4ezg8G7X2Gg2jvTdyvacNNCgTQ92bBKHy', '18');

-- --------------------------------------------------------

--
-- Table structure for table `tutor`
--

CREATE TABLE `tutor` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `number` varchar(40) NOT NULL,
  `password` varchar(90) NOT NULL,
  `email` varchar(30) NOT NULL,
  `teaching` int(100) NOT NULL,
  `address` varchar(40) NOT NULL,
  `subject` varchar(40) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tutor`
--

INSERT INTO `tutor` (`id`, `name`, `number`, `password`, `email`, `teaching`, `address`, `subject`) VALUES
(33, 'Tejas', '9886750312', '$2y$10$ZD7skOQXWxR0g25GK91zfumWH.tVS4JLDE5oNR2/qKAMg7rMNoLOi', 'tejasnitk@gmail.com', 14, 'Bangalore', 'Mathematics'),
(34, 'Sabari', '7397078885', '$2y$10$pa0PAqdq5/9f9EtIDPQpku.aOVBnSAx2DwmzAgNNY51UIm4B/lw0.', 'sabyog@gmail.com', 10, 'cbe', 'Mathematics'),
(35, 'Sabari', '7397078885', '$2y$10$uhvQhfThuSpiLAtReBTneeVxRBvHYO0ZwrE0NayAG5x80O6uyKY7i', 'sabyog@gmail.com', 10, 'cbe', 'Mathematics'),
(36, 'Sabarinathan', '7397078885', '$2y$10$kX1nZHcmI9/APSPg/ZJfPuDHFRW0X10jr/N/aEun5ABmztuAQmbOC', 'sabyog@gmail.com', 10, 'cbe', 'Mathematics'),
(37, 'kirupa', '9842242653', '$2y$10$KLLIRJe3cFPADWJNB4ZBxOLvmXee2lREcup39tqvLbHNqOHgphkOq', 'gateway.kirupa@gmail.com', 12, 'madurai', 'Computer-science');

-- --------------------------------------------------------

--
-- Table structure for table `tutor_request`
--

CREATE TABLE `tutor_request` (
  `id` int(11) NOT NULL,
  `gurdian_name` varchar(40) NOT NULL,
  `gurdian_mobile` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `subject` varchar(40) NOT NULL,
  `teaching` varchar(40) NOT NULL,
  `area` varchar(40) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tutor_request`
--

INSERT INTO `tutor_request` (`id`, `gurdian_name`, `gurdian_mobile`, `email`, `subject`, `teaching`, `area`) VALUES
(14, 'ilakiya', '9994993885', 'N/A', 'Mathematics', '10', 'cbe'),
(15, 'VENU MATHAV N', '9632145879', 'N/A', 'computerscience', '12', 'madurai');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(90) NOT NULL,
  `usertype` varchar(40) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `email`, `password`, `usertype`) VALUES
(31, 'gateway.kirupa@gmail.com', '$2y$10$KLLIRJe3cFPADWJNB4ZBxOLvmXee2lREcup39tqvLbHNqOHgphkOq', 'teacher'),
(30, 'venumathav', '$2y$10$Gt/PjUhkFIAL.NY0Q0aj4ezg8G7X2Gg2jvTdyvacNNCgTQ92bBKHy', 'student'),
(29, 'sabyog@gmail.com', '$2y$10$kX1nZHcmI9/APSPg/ZJfPuDHFRW0X10jr/N/aEun5ABmztuAQmbOC', 'teacher'),
(28, 'skilakiya', '$2y$10$WcHBVaC6eLXEMxgJLfaifOIG728HBDgRw3T20/2rRToBTTLHKS73C', 'student');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_tutor`
--
ALTER TABLE `add_tutor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ajax`
--
ALTER TABLE `ajax`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tutor`
--
ALTER TABLE `tutor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tutor_request`
--
ALTER TABLE `tutor_request`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_tutor`
--
ALTER TABLE `add_tutor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `ajax`
--
ALTER TABLE `ajax`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tutor`
--
ALTER TABLE `tutor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `tutor_request`
--
ALTER TABLE `tutor_request`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
